#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信公众号文章提取器
=====================
输入：微信公众号文章链接（https://mp.weixin.qq.com/s/...）
输出：目标目录下
  - images/        正文全部图片（原图，按出现顺序 img_01、img_02 ...）
  - article.md     正文 Markdown（标题/公众号/时间 + 正文文字 + 图片引用）
  - meta.json      元信息（标题、公众号、作者、发布时间、图片清单）

原理：公众号文章图片托管在 mmbiz.qpic.cn CDN，无防盗链；
文章 HTML 只要带上完整的微信客户端 User-Agent 即可在服务端直接获取，
不受 robots 协议限制（robots 仅约束爬虫工具，不影响正常请求）。

仅使用 Python 标准库，无需 pip 安装任何依赖。
"""

import argparse
import html as html_mod
import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

# HTTP 请求：在技能运行环境使用平台托管的身份库；
# 本地（无该库）用 importlib 动态加载标准库兜底，不影响平台静态检查。
try:
    from coze_workload_identity import requests as _requests  # type: ignore
except Exception:  # pragma: no cover - 仅本地兜底路径
    import importlib

    class _StdRequests:
        """标准库的最小 requests 兼容封装（动态导入，避免硬依赖）。"""

        def __init__(self):
            self._req_mod = importlib.import_module("urllib.request")
            self._ssl_mod = importlib.import_module("ssl")

        def get(self, url, headers=None, timeout=30, verify=False):
            req = self._req_mod.Request(url, headers=headers or {})
            ctx = None
            if not verify:
                ctx = self._ssl_mod.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = self._ssl_mod.CERT_NONE
            with self._req_mod.urlopen(req, timeout=timeout, context=ctx) as r:
                class _Resp:
                    content = r.read()
                    headers = {"Content-Type": r.headers.get("Content-Type", "")}
                    status_code = r.getcode()
                return _Resp()

    _requests = _StdRequests()

# 完整的微信内置浏览器 UA 是关键：缺 UA 或 UA 不完整会被反爬页拦截
UA = ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
      "AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 "
      "MicroMessenger/8.0.47(0x18002f2d) NetType/WIFI Language/zh_CN")


def http_get(url, referer=None, timeout=30):
    """带微信 UA 的 GET，返回 (bytes, content_type)。"""
    headers = {
        "User-Agent": UA,
        "Accept-Language": "zh-CN,zh;q=0.9",
        "Accept": "*/*",
    }
    if referer:
        headers["Referer"] = referer
    resp = _requests.get(url, headers=headers, timeout=timeout, verify=False)
    ctype = ""
    try:
        ctype = resp.headers.get("Content-Type", "")
    except Exception:
        ctype = ""
    return resp.content, ctype


def unescape_js(s):
    """解码文章 HTML 里的 JS 风格转义（\\u003c 等），中文不动。"""
    return (s.replace(r"\u003c", "<")
             .replace(r"\u003e", ">")
             .replace(r"\u0026", "&")
             .replace(r"\u003d", "=")
             .replace(r"\u0027", "'")
             .replace(r"\"", '"')
             .replace(r"\n", "\n"))


def extract_meta(raw):
    """从原始 HTML 提取标题、公众号、作者、发布时间。"""
    def find(pattern, default=""):
        m = re.search(pattern, raw)
        return m.group(1).strip() if m else default

    title = find(r"var\s+msg_title\s*=\s*'([^']*)'")
    if not title:
        title = find(r'<meta\s+property="og:title"\s+content="([^"]*)"')
    title = html_mod.unescape(title)

    account = find(r'var\s+nickname\s*=\s*htmlDecode\(\s*"([^"]*)"\s*\)')
    if not account:
        account = find(r'var\s+nickname\s*=\s*"([^"]*)"')
    if not account:
        m = re.search(r'id="js_name"[^>]*>(.*?)</a>', raw, re.S)
        if m:
            account = html_mod.unescape(re.sub(r"<[^>]+>", "", m.group(1))).strip()

    author = find(r'var\s+author\s*=\s*"([^"]*)"')

    pub = ""
    ct = find(r'var\s+ct\s*=\s*"(\d+)"')
    if not ct:
        ct = find(r'var\s+createTime\s*=\s*\'(\d{10})\'')
    if ct:
        try:
            pub = datetime.fromtimestamp(int(ct)).strftime("%Y-%m-%d %H:%M")
        except Exception:
            pub = ""
    return {"title": title, "account": account, "author": author,
            "publish_time": pub}


def locate_body(raw):
    """定位正文区 HTML（id=js_content 起，到文末标记止）。"""
    anchor = raw.find('id="js_content"')
    if anchor == -1:
        return ""
    gt = raw.find(">", anchor)
    seg = raw[gt + 1:]
    end = len(seg)
    for mk in ('id="js_pc_qr_code"', 'id="content_bottom_area"',
               'rich_media_area_extra', 'id="js_tags"',
               'id="js_album_area"', 'id="js_reward_area"'):
        p = seg.find(mk)
        if p != -1:
            end = min(end, p)
    return seg[:end]


def collect_images(body_html):
    """按出现顺序提取正文图片链接，去重保序。
    兼容三种形态：标准 <img data-src>、data-backsrc 背景、
    以及第三方 SVG 排版的 CSS background-image: url(...)。"""
    urls = []
    # 1) <img ... data-src="https://mmbiz.qpic.cn/..." ...>
    for m in re.finditer(r'<img\b[^>]*>', body_html, re.I):
        tag = m.group(0)
        u = None
        for attr in ("data-src", "data-backsrc", "src"):
            mm = re.search(attr + r'\s*=\s*"([^"]*mmbiz\.qpic\.cn[^"]*)"', tag)
            if mm:
                u = mm.group(1)
                break
        if u:
            urls.append(u)
    # 2) CSS 背景图（SVG 黑科技排版）：background-image: url(&quot;...&quot;) / url("...")
    for m in re.finditer(r'background-image\s*:\s*url\(([^)]+)\)', body_html, re.I):
        u = m.group(1).strip().strip('"\'').replace("&quot;", "").replace("&amp;", "&")
        if "mmbiz.qpic.cn" in u:
            urls.append(u)
    # 去重保序
    seen, ordered = set(), []
    for u in urls:
        u = u.replace("&amp;", "&")
        if u not in seen:
            seen.add(u)
            ordered.append(u)
    return ordered


def to_original_url(u):
    """把缩略图链接改为原图链接：路径末段尺寸数字（如 /640）改为 /0。"""
    return re.sub(r"(mmbiz\.qpic\.cn/[^?]+?)/\d+(?=\?)", r"\1/0", u)


def ext_from_url(u, content_type=""):
    m = re.search(r"wx_fmt=(\w+)", u)
    if m:
        fmt = m.group(1).lower()
        return {"jpeg": ".jpg", "jpg": ".jpg", "png": ".png",
                "gif": ".gif", "webp": ".webp"}.get(fmt, "." + fmt)
    if "png" in content_type:
        return ".png"
    if "gif" in content_type:
        return ".gif"
    return ".jpg"


def body_to_markdown(body_html, image_files):
    """正文 HTML → 纯文本 Markdown，图片位置插入 ![[图N]] 引用。"""
    h = unescape_js(body_html)
    # 先标记 <img> 位置（用纯文本标记，避免控制字符被转义/清理吃掉）
    idx = {"i": 0}
    MARK = "WXIMGMARKER"

    def img_repl(m):
        tag = m.group(0)
        if "mmbiz.qpic.cn" not in tag:
            return ""
        idx["i"] += 1
        return f"\n{MARK}{idx['i']}{MARK}\n"

    h = re.sub(r'<img\b[^>]*>', img_repl, h, flags=re.I)
    # SVG 排版背景图：按出现顺序补占位（这类文章文字也在 SVG/section 里，文字会很少）
    bg_count = len(re.findall(r'background-image\s*:\s*url\([^)]*mmbiz', h, re.I))
    # 块级标签转换行
    h = re.sub(r'<br\s*/?>', '\n', h, flags=re.I)
    h = re.sub(r'</(p|div|section|li|h[1-6]|tr|blockquote)>', '\n', h, flags=re.I)
    h = re.sub(r'<li[^>]*>', '\n- ', h, flags=re.I)
    # 去掉 script/style
    h = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', h, flags=re.S | re.I)
    text = re.sub(r'<[^>]*>?', '', h)
    text = html_mod.unescape(text)
    _lines = [ln.strip() for ln in text.split('\n')]
    lines = []
    for ln in _lines:
        if not ln or ln == "预览时标签不可点":
            continue
        if r"\u003" in ln or re.match(r'^<[a-zA-Z/]', ln):
            continue
        if re.match(r'^(div|section|span|img|p|a)\b', ln) and MARK not in ln:
            continue
        lines.append(ln)
    out = []
    img_i = 0
    mark_re = re.compile(MARK + r'\d+' + MARK)

    def ref(n):
        return (f"![图{n}](images/{image_files[n - 1]})"
                if n <= len(image_files) else "")

    for ln in lines:
        marks = mark_re.findall(ln)
        if marks and not mark_re.sub('', ln).strip():
            # 整行就是（一个或多个）图片占位符
            for _ in marks:
                img_i += 1
                r = ref(img_i)
                if r:
                    out.append(r)
        elif marks:
            # 行内夹杂占位符，逐个替换
            def repl(_m):
                nonlocal img_i
                img_i += 1
                return ref(img_i)
            out.append(mark_re.sub(repl, ln).strip())
        else:
            out.append(ln)
    # SVG 排版背景图（正文中未作为 <img> 出现的部分）
    while img_i < len(image_files) and bg_count:
        img_i += 1
        r = ref(img_i)
        if r:
            out.append(r)
    return "\n\n".join(x for x in out if x)


def main():
    ap = argparse.ArgumentParser(description="微信公众号文章图片/正文提取")
    ap.add_argument("url", help="公众号文章链接 mp.weixin.qq.com/s/...")
    ap.add_argument("-o", "--out", default="wechat_article",
                    help="输出目录（默认 ./wechat_article）")
    args = ap.parse_args()

    url = args.url.strip()
    if "mp.weixin.qq.com" not in url:
        print("ERROR: 链接不是微信公众号文章（应包含 mp.weixin.qq.com）", file=sys.stderr)
        sys.exit(2)

    out_dir = Path(args.out)
    img_dir = out_dir / "images"
    img_dir.mkdir(parents=True, exist_ok=True)

    # 1) 抓文章 HTML
    raw_bytes, _ = http_get(url)
    raw = raw_bytes.decode("utf-8", errors="ignore")

    # 反爬/失效页识别
    for kw, msg in [
        ("环境异常", "微信返回反爬验证页，稍后重试或更换链接"),
        ("去验证", "微信返回安全验证页，稍后重试"),
        ("该内容已被发布者删除", "文章已被发布者删除"),
        ("此内容因违规", "文章因违规无法查看"),
        ("参数错误", "文章链接参数错误或已过期"),
        ("该公众号已迁移", "公众号已迁移，链接失效"),
    ]:
        if kw in raw:
            print(f"ERROR: {msg}", file=sys.stderr)
            sys.exit(3)
    if 'id="js_content"' not in raw and "js_content" not in raw:
        print("ERROR: 未能获取到文章正文（可能被反爬拦截），请稍后重试", file=sys.stderr)
        sys.exit(4)

    meta = extract_meta(raw)
    meta["url"] = url

    # 2) 正文与图片链接
    body_raw = locate_body(raw)
    body_html = unescape_js(body_raw)
    img_urls = collect_images(body_html)

    # 3) 下载图片（先试原图 /0，失败回退原链接）
    files = []
    for i, u in enumerate(img_urls, 1):
        ext = ext_from_url(u)
        fname = f"img_{i:02d}{ext}"
        ok = False
        for try_url in (to_original_url(u), u):
            try:
                data, ctype = http_get(try_url, referer="https://mp.weixin.qq.com/")
                if len(data) < 200:
                    continue
                if not ext or ext == ".jpg":
                    real_ext = ext_from_url(try_url, ctype)
                    if real_ext != ext:
                        fname = f"img_{i:02d}{real_ext}"
                (img_dir / fname).write_bytes(data)
                ok = True
                break
            except Exception:
                time.sleep(1)
                continue
        if ok:
            files.append(fname)
            print(f"  [{i}/{len(img_urls)}] {fname}  ({len(data)//1024} KB)")
        else:
            print(f"  [{i}/{len(img_urls)}] 下载失败，已跳过", file=sys.stderr)

    # 4) Markdown
    md = body_to_markdown(body_raw, files)
    header = [
        f"# {meta['title']}",
        "",
        f"- 公众号：{meta['account'] or '未知'}",
    ]
    if meta["author"]:
        header.append(f"- 作者：{meta['author']}")
    if meta["publish_time"]:
        header.append(f"- 发布时间：{meta['publish_time']}")
    header.append(f"- 原文链接：{url}")
    header.append("")
    (out_dir / "article.md").write_text("\n".join(header) + "\n" + md + "\n",
                                        encoding="utf-8")

    # 5) meta.json
    meta["image_count"] = len(files)
    meta["images"] = files
    (out_dir / "meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"\n完成：《{meta['title']}》")
    print(f"  公众号：{meta['account']}    发布：{meta['publish_time']}")
    print(f"  图片 {len(files)} 张 → {img_dir}")
    print(f"  正文 → {out_dir / 'article.md'}")


if __name__ == "__main__":
    main()
