#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
md_to_docx.py — 把转录用 Markdown 全文稿转换为排版规整的 Word (.docx)。

纯 Python 标准库实现（zipfile + 手写 OOXML），无需 pip 安装任何依赖，
无网络请求，本地/沙箱均可运行。

用法：
    python3 md_to_docx.py <input.md> <output.docx> [--title "文档标题"]

支持的 Markdown 子集（覆盖转录稿全部写法）：
    # / ## / ### / #### 标题
    表格（| a | b |，第二行为 |---|---| 分隔行）→ 改良三线表
    > 引用块
    - / * 无序列表；1. 有序列表
    **粗体**、*斜体*、`行内代码`
    ![alt](...) 图片标记 → 居中灰色图注（转录稿中一般不含图片）
    --- 水平分隔线

排版规范：A4；正文中文宋体、英文 Times New Roman、黑色、小四、1.5 倍行距；
标题中文黑体加粗；表格为改良三线表（上下粗线 + 表头下细线，无竖线）。
"""

import sys
import os
import re
import zipfile
import html
import argparse


# --------------------------- OOXML 基础构件 ---------------------------

NS_W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'

FONT_BODY = '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="宋体"/>'
FONT_HEAD = '<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="黑体"/>'
FONT_MONO = '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:eastAsia="宋体"/>'


def esc(text):
    return html.escape(text, quote=False)


def run(text, bold=False, italic=False, mono=False, size=24, head=False, color="000000"):
    """生成一个 w:r。size 为半磅值（小四=24）。"""
    if text == "":
        return ""
    rpr = [FONT_HEAD if head else (FONT_MONO if mono else FONT_BODY)]
    rpr.append('<w:color w:val="%s"/>' % color)
    if bold:
        rpr.append("<w:b/>")
    if italic:
        rpr.append("<w:i/>")
    rpr.append('<w:sz w:val="%d"/><w:szCs w:val="%d"/>' % (size, size))
    return (
        "<w:r><w:rPr>%s</w:rPr>"
        '<w:t xml:space="preserve">%s</w:t></w:r>'
        % ("".join(rpr), esc(text))
    )


INLINE_RE = re.compile(r"(\*\*.+?\*\*|`.+?`|\*[^*]+?\*)")


def inline_runs(text, size=24, base_bold=False, head=False, color="000000"):
    """把含 **粗体** / `代码` / *斜体* 的行内文本拆成多个 run。"""
    parts = INLINE_RE.split(text)
    out = []
    for p in parts:
        if not p:
            continue
        if p.startswith("**") and p.endswith("**") and len(p) >= 4:
            out.append(run(p[2:-2], bold=True, size=size, head=head, color=color))
        elif p.startswith("`") and p.endswith("`") and len(p) >= 2:
            out.append(run(p[1:-1], mono=True, size=size, color=color))
        elif p.startswith("*") and p.endswith("*") and len(p) >= 2:
            out.append(run(p[1:-1], italic=True, size=size, head=head, color=color))
        else:
            out.append(run(p, bold=base_bold, size=size, head=head, color=color))
    return "".join(out)


def para(runs_xml, jc=None, before=0, after=120, line=360, ind_left=None,
         ind_hang=None, border_left=False, size=24):
    ppr = ['<w:spacing w:before="%d" w:after="%d" w:line="%d" w:lineRule="auto"/>'
           % (before, after, line)]
    if jc:
        ppr.append('<w:jc w:val="%s"/>' % jc)
    if ind_left is not None:
        hang = ' w:hanging="%d"' % ind_hang if ind_hang else ""
        ppr.append('<w:ind w:left="%d"%s/>' % (ind_left, hang))
    if border_left:
        ppr.append(
            '<w:pBdr><w:left w:val="single" w:sz="18" w:space="8" w:color="999999"/></w:pBdr>'
        )
    return "<w:p><w:pPr>%s</w:pPr>%s</w:p>" % ("".join(ppr), runs_xml)


def heading(text, level):
    """level 1=文档标题(居中) 2=章 3=节 4=小节"""
    if level == 1:
        return para(inline_runs(text, size=44, base_bold=True, head=True),
                    jc="center", before=120, after=360, line=360)
    sizes = {2: 32, 3: 28, 4: 24}
    befores = {2: 360, 3: 240, 4: 180}
    afters = {2: 160, 3: 120, 4: 100}
    return para(inline_runs(text, size=sizes[level], base_bold=True, head=True),
                before=befores[level], after=afters[level], line=360)


def hr_para():
    return (
        '<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" '
        'w:color="999999"/></w:pBdr><w:spacing w:after="120"/></w:pPr></w:p>'
    )


def table_xml(rows):
    """rows: list[list[str]]，第一行为表头。生成改良三线表。"""
    ncol = max(len(r) for r in rows)
    # 列宽：A4 正文宽约 9026 twips
    total = 9026
    col_w = total // ncol
    grid = "".join('<w:gridCol w:w="%d"/>' % col_w for _ in range(ncol))

    out = [
        "<w:tbl>",
        '<w:tblPr>',
        '<w:tblW w:w="%d" w:type="dxa"/>' % total,
        '<w:jc w:val="center"/>',
        '<w:tblBorders>',
        '<w:top w:val="single" w:sz="12" w:space="0" w:color="000000"/>',
        '<w:bottom w:val="single" w:sz="12" w:space="0" w:color="000000"/>',
        '<w:left w:val="none" w:sz="0" w:space="0" w:color="auto"/>',
        '<w:right w:val="none" w:sz="0" w:space="0" w:color="auto"/>',
        '<w:insideH w:val="none" w:sz="0" w:space="0" w:color="auto"/>',
        '<w:insideV w:val="none" w:sz="0" w:space="0" w:color="auto"/>',
        '</w:tblBorders>',
        '<w:tblCellMar><w:top w:w="40" w:type="dxa"/><w:left w:w="108" w:type="dxa"/>'
        '<w:bottom w:w="40" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar>',
        '</w:tblPr>',
        "<w:tblGrid>%s</w:tblGrid>" % grid,
    ]

    for ri, row in enumerate(rows):
        out.append("<w:tr>")
        # 补齐列数
        cells = list(row) + [""] * (ncol - len(row))
        for ci, cell in enumerate(cells):
            cell = cell.strip()
            tcpr = ['<w:tcW w:w="%d" w:type="dxa"/>' % col_w,
                    '<w:vAlign w:val="center"/>']
            # 表头行底部加细线（三线表的表头下线）
            if ri == 0:
                tcpr.append(
                    '<w:tcBorders><w:bottom w:val="single" w:sz="6" w:space="0" '
                    'w:color="000000"/></w:tcBorders>'
                )
            is_head = (ri == 0)
            jc = "center" if (is_head or _looks_numeric(cell)) else "left"
            cell_runs = inline_runs(cell, size=21, base_bold=is_head,
                                    head=is_head)
            out.append(
                '<w:tc><w:tcPr>%s</w:tcPr>'
                '<w:p><w:pPr><w:spacing w:after="20" w:line="276" w:lineRule="auto"/>'
                '<w:jc w:val="%s"/></w:pPr>%s</w:p></w:tc>'
                % ("".join(tcpr), jc, cell_runs)
            )
        out.append("</w:tr>")
    out.append("</w:tbl>")
    # 表格后补一个空段落，保证与下文间距
    out.append('<w:p><w:pPr><w:spacing w:after="120"/></w:pPr></w:p>')
    return "".join(out)


def _looks_numeric(s):
    """判断单元格是否为数值类（数字/百分比/年份等），用于居中对齐。
    纯中文短词（如"豆包"）不算；含数字且去掉数字、符号、单位后几乎无残留才算。"""
    t = s.strip()
    if not t or not re.search(r"\d", t):
        return False
    residual = re.sub(r"[\d,.%+\-—–~/:：()（）\s]", "", t)
    residual = re.sub(r"[亿万元年季度月QqA-Za-z.％]", "", residual)
    return len(residual) <= 2


# --------------------------- Markdown 解析 ---------------------------

TABLE_SEP_RE = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)+\|?\s*$")


def split_table_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [c.strip() for c in line.split("|")]


def md_to_body(md_text):
    lines = md_text.splitlines()
    body = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i].rstrip()
        stripped = line.strip()

        # 空行
        if not stripped:
            i += 1
            continue

        # 表格块
        if stripped.startswith("|") and i + 1 < n and TABLE_SEP_RE.match(lines[i + 1].strip()):
            rows = [split_table_row(stripped)]
            j = i + 2
            while j < n and lines[j].strip().startswith("|"):
                rows.append(split_table_row(lines[j].strip()))
                j += 1
            body.append(table_xml(rows))
            i = j
            continue

        # 图片标记（转录稿一般不含）
        m_img = re.match(r"^!\[(.*?)\]\((.*?)\)\s*$", stripped)
        if m_img:
            alt = m_img.group(1)
            if alt:
                body.append(para(run("［%s］" % alt, size=20, color="666666"),
                                 jc="center", after=120))
            i += 1
            continue

        # 标题
        m_h = re.match(r"^(#{1,4})\s+(.*)$", stripped)
        if m_h:
            body.append(heading(m_h.group(2).strip(), len(m_h.group(1))))
            i += 1
            continue

        # 水平分隔线
        if re.match(r"^(-{3,}|\*{3,}|_{3,})$", stripped):
            body.append(hr_para())
            i += 1
            continue

        # 引用块
        if stripped.startswith(">"):
            qtext = re.sub(r"^>\s?", "", stripped)
            m_q = re.match(r"^[-*]\s+(.*)$", qtext)
            if m_q:
                q_runs = run("•  ", size=22) + inline_runs(m_q.group(1), size=22)
            else:
                q_runs = inline_runs(qtext, size=22)
            body.append(para(q_runs, ind_left=420, ind_hang=240,
                             border_left=True, after=80, line=320))
            i += 1
            continue

        # 无序列表
        m_ul = re.match(r"^[-*]\s+(.*)$", stripped)
        if m_ul:
            body.append(para(
                run("•  ", size=24) + inline_runs(m_ul.group(1), size=24),
                ind_left=480, ind_hang=240, after=60, line=340))
            i += 1
            continue

        # 有序列表
        m_ol = re.match(r"^(\d+)[\.、]\s+(.*)$", stripped)
        if m_ol:
            body.append(para(
                run("%s.  " % m_ol.group(1), size=24) + inline_runs(m_ol.group(2), size=24),
                ind_left=540, ind_hang=300, after=60, line=340))
            i += 1
            continue

        # 普通段落
        body.append(para(inline_runs(stripped, size=24), jc="both"))
        i += 1

    return "".join(body)


# --------------------------- docx 打包 ---------------------------

CONTENT_TYPES = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    '<Default Extension="xml" ContentType="application/xml"/>'
    '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
    '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
    '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
    '</Types>'
)

RELS = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
    '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
    '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
    '</Relationships>'
)


def document_xml(body_xml):
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document %s>'
        '<w:body>%s'
        '<w:sectPr>'
        '<w:pgSz w:w="11906" w:h="16838"/>'
        '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" '
        'w:header="851" w:footer="992" w:gutter="0"/>'
        '</w:sectPr>'
        '</w:body></w:document>' % (NS_W, body_xml)
    )


def core_xml(title):
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        '<dc:title>%s</dc:title><dc:creator>wechat-article-transcriber</dc:creator>'
        '</cp:coreProperties>' % esc(title)
    )


APP_XML = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
    '<Application>wechat-article-transcriber</Application></Properties>'
)


def convert(md_path, docx_path, title=None):
    with open(md_path, "r", encoding="utf-8") as f:
        md_text = f.read()

    if not title:
        m = re.search(r"^#\s+(.+)$", md_text, re.M)
        title = m.group(1).strip() if m else os.path.splitext(os.path.basename(md_path))[0]

    body_xml = md_to_body(md_text)
    doc_xml = document_xml(body_xml)

    with zipfile.ZipFile(docx_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", CONTENT_TYPES)
        z.writestr("_rels/.rels", RELS)
        z.writestr("word/document.xml", doc_xml)
        z.writestr("docProps/core.xml", core_xml(title))
        z.writestr("docProps/app.xml", APP_XML)

    return docx_path


def main():
    ap = argparse.ArgumentParser(description="Markdown 转录稿转 Word（.docx）")
    ap.add_argument("input_md", help="输入 Markdown 文件路径")
    ap.add_argument("output_docx", help="输出 .docx 文件路径")
    ap.add_argument("--title", default=None, help="文档标题（默认取第一个 # 标题）")
    args = ap.parse_args()

    if not os.path.exists(args.input_md):
        print("输入文件不存在：%s" % args.input_md)
        sys.exit(1)

    out = convert(args.input_md, args.output_docx, args.title)
    size = os.path.getsize(out)
    print("已生成：%s（%.1f KB）" % (out, size / 1024))


if __name__ == "__main__":
    main()
